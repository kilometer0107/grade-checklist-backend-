package com.team.grade_checklist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeChecklistApplicationTests {

	@Test
	void contextLoads() {
	}

}
