package com.team.grade_checklist.domain.user;

public enum GraduationTrack { //졸업 트랙 종류
    INTENSIVE, //심화전공
    MINOR, //부전공
    DOUBLE //다전공
}
